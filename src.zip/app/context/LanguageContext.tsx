import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.cv': 'CV',
    'nav.projects': 'Projects',
    'nav.about': 'About',
    'nav.letter': 'Letter of Intent',
    'nav.personal': 'Personal',
    
    // CV Page
    'cv.title': 'Curriculum Vitae',
    'cv.download': 'Download PDF',
    'cv.loading': 'Loading CV...',
    'cv.placeholder': 'Your CV will be displayed here. Upload your CV PDF to replace this placeholder.',
    
    // Projects Page
    'projects.title': 'My Projects',
    'projects.subtitle': 'A showcase of my work and applications',
    'projects.demo': 'Demo Video',
    'projects.viewProject': 'View Project',
    
    // About Page
    'about.title': 'About Me',
    'about.subtitle': 'Learn more about my background and expertise',
    
    // Letter Page
    'letter.title': 'Letter of Intent',
    'letter.subtitle': 'My motivation and career aspirations',
    
    // Personal Page
    'personal.title': 'Personal',
    'personal.subtitle': 'Travels, accomplishments, and interests',
    'personal.trips': 'Travels',
    'personal.accomplishments': 'Accomplishments',
    'personal.interests': 'Interests',
  },
  fr: {
    // Navigation
    'nav.cv': 'CV',
    'nav.projects': 'Projets',
    'nav.about': 'À propos',
    'nav.letter': 'Lettre de motivation',
    'nav.personal': 'Personnel',
    
    // CV Page
    'cv.title': 'Curriculum Vitae',
    'cv.download': 'Télécharger PDF',
    'cv.loading': 'Chargement du CV...',
    'cv.placeholder': 'Votre CV sera affiché ici. Téléchargez votre CV PDF pour remplacer cet espace réservé.',
    
    // Projects Page
    'projects.title': 'Mes Projets',
    'projects.subtitle': 'Une vitrine de mon travail et applications',
    'projects.demo': 'Vidéo de démonstration',
    'projects.viewProject': 'Voir le projet',
    
    // About Page
    'about.title': 'À propos de moi',
    'about.subtitle': 'En savoir plus sur mon parcours et mon expertise',
    
    // Letter Page
    'letter.title': 'Lettre de motivation',
    'letter.subtitle': 'Ma motivation et mes aspirations professionnelles',
    
    // Personal Page
    'personal.title': 'Personnel',
    'personal.subtitle': 'Voyages, réalisations et centres d\'intérêt',
    'personal.trips': 'Voyages',
    'personal.accomplishments': 'Réalisations',
    'personal.interests': 'Centres d\'intérêt',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}

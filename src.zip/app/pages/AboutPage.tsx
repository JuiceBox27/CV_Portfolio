import { useLanguage } from '../context/LanguageContext';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { Card, CardContent } from '../components/ui/card';
import { Briefcase, GraduationCap, Code, Award } from 'lucide-react';

export function AboutPage() {
  const { language, t } = useLanguage();

  const content = {
    en: {
      intro: "I am a passionate software developer with expertise in building modern web and mobile applications. With a strong foundation in computer science and years of hands-on experience, I specialize in creating efficient, scalable, and user-friendly solutions.",
      background: "My journey in technology began with a fascination for problem-solving and has evolved into a career dedicated to building impactful digital products. I thrive in collaborative environments and enjoy tackling complex challenges.",
      expertise: "Throughout my career, I've worked with diverse teams and technologies, from startups to enterprise-level projects. I'm committed to continuous learning and staying current with industry best practices.",
      approach: "I believe in writing clean, maintainable code and creating solutions that not only meet technical requirements but also provide exceptional user experiences. My approach combines technical excellence with strong communication and teamwork skills.",
    },
    fr: {
      intro: "Je suis un développeur de logiciels passionné avec une expertise dans la création d'applications web et mobiles modernes. Avec une solide formation en informatique et des années d'expérience pratique, je me spécialise dans la création de solutions efficaces, évolutives et conviviales.",
      background: "Mon parcours dans la technologie a commencé par une fascination pour la résolution de problèmes et a évolué vers une carrière dédiée à la construction de produits numériques à fort impact. Je m'épanouis dans des environnements collaboratifs et j'aime relever des défis complexes.",
      expertise: "Tout au long de ma carrière, j'ai travaillé avec des équipes et des technologies diverses, des startups aux projets d'entreprise. Je m'engage dans l'apprentissage continu et reste à jour avec les meilleures pratiques de l'industrie.",
      approach: "Je crois en l'écriture de code propre et maintenable et en la création de solutions qui non seulement répondent aux exigences techniques mais offrent également des expériences utilisateur exceptionnelles. Mon approche combine l'excellence technique avec de solides compétences en communication et travail d'équipe.",
    },
  };

  const text = content[language];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">{t('about.title')}</h1>
        <p className="text-lg text-slate-600">{t('about.subtitle')}</p>
      </div>

      {/* Profile Section */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="grid md:grid-cols-3 gap-8 p-8">
          {/* Profile Image */}
          <div className="flex justify-center items-start">
            <div className="w-48 h-48 rounded-full overflow-hidden shadow-md">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1613759612065-d5971d32ca49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NzAxOTc5NDh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Bio */}
          <div className="md:col-span-2 space-y-4">
            <h2 className="text-2xl font-semibold text-slate-900">Professional Background</h2>
            <p className="text-slate-700 leading-relaxed">{text.intro}</p>
            <p className="text-slate-700 leading-relaxed">{text.background}</p>
            <p className="text-slate-700 leading-relaxed">{text.expertise}</p>
          </div>
        </div>
      </div>

      {/* Key Highlights */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <Briefcase className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <h3 className="font-semibold text-slate-900 mb-1">8+ Years</h3>
            <p className="text-sm text-slate-600">Professional Experience</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Code className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <h3 className="font-semibold text-slate-900 mb-1">15+ Projects</h3>
            <p className="text-sm text-slate-600">Successfully Delivered</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <GraduationCap className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <h3 className="font-semibold text-slate-900 mb-1">M.Sc.</h3>
            <p className="text-sm text-slate-600">Computer Science</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Award className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <h3 className="font-semibold text-slate-900 mb-1">5+ Certifications</h3>
            <p className="text-sm text-slate-600">Industry Recognized</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Sections */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Technical Skills */}
        <Card>
          <CardContent className="pt-6 space-y-4">
            <h3 className="text-xl font-semibold text-slate-900">Technical Expertise</h3>
            <div className="space-y-3">
              <div>
                <h4 className="font-medium text-slate-700 mb-2">Frontend Development</h4>
                <div className="flex flex-wrap gap-2">
                  {['React', 'Vue.js', 'TypeScript', 'Tailwind CSS', 'Next.js'].map((skill) => (
                    <span key={skill} className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium text-slate-700 mb-2">Backend Development</h4>
                <div className="flex flex-wrap gap-2">
                  {['Node.js', 'Python', 'PostgreSQL', 'MongoDB', 'REST APIs'].map((skill) => (
                    <span key={skill} className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium text-slate-700 mb-2">DevOps & Tools</h4>
                <div className="flex flex-wrap gap-2">
                  {['Docker', 'Git', 'AWS', 'CI/CD', 'Agile'].map((skill) => (
                    <span key={skill} className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Soft Skills */}
        <Card>
          <CardContent className="pt-6 space-y-4">
            <h3 className="text-xl font-semibold text-slate-900">Professional Skills</h3>
            <ul className="space-y-3 text-slate-700">
              <li className="flex items-start gap-2">
                <span className="text-slate-900">•</span>
                <span>Strong problem-solving and analytical thinking</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-900">•</span>
                <span>Excellent communication and team collaboration</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-900">•</span>
                <span>Project management and leadership experience</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-900">•</span>
                <span>Adaptability and continuous learning mindset</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-slate-900">•</span>
                <span>Attention to detail and quality-focused approach</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Philosophy */}
      <div className="bg-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-semibold text-slate-900 mb-4">My Approach</h2>
        <p className="text-slate-700 leading-relaxed text-lg">{text.approach}</p>
      </div>
    </div>
  );
}

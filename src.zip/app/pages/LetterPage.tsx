import { useLanguage } from '../context/LanguageContext';

export function LetterPage() {
  const { language, t } = useLanguage();

  const content = {
    en: {
      greeting: "Dear Hiring Manager,",
      para1: "I am writing to express my strong interest in joining your organization. With a proven track record of delivering high-quality software solutions and a passion for technological innovation, I am excited about the opportunity to contribute to your team's success.",
      para2: "Throughout my career, I have consistently demonstrated my ability to tackle complex technical challenges while maintaining a focus on user experience and business objectives. My experience spans the full software development lifecycle, from initial concept and design through deployment and maintenance. I have worked collaboratively with cross-functional teams, including designers, product managers, and stakeholders, to deliver solutions that exceed expectations.",
      para3: "What drives me is the opportunity to create meaningful impact through technology. I am particularly drawn to projects that push the boundaries of what's possible, require innovative thinking, and ultimately improve people's lives or businesses. I believe in the power of clean, maintainable code and the importance of continuous learning in our rapidly evolving industry.",
      para4: "I am especially excited about the possibility of working with your organization because of your reputation for excellence and innovation. I am confident that my technical skills, combined with my commitment to professional growth and teamwork, would make me a valuable addition to your team.",
      para5: "I look forward to the opportunity to discuss how my experience and enthusiasm can contribute to your organization's continued success. Thank you for considering my application.",
      closing: "Sincerely,",
      signature: "Your Name",
    },
    fr: {
      greeting: "Madame, Monsieur,",
      para1: "Je vous écris pour exprimer mon vif intérêt à rejoindre votre organisation. Avec un historique éprouvé de livraison de solutions logicielles de haute qualité et une passion pour l'innovation technologique, je suis enthousiaste à l'idée de contribuer au succès de votre équipe.",
      para2: "Tout au long de ma carrière, j'ai constamment démontré ma capacité à relever des défis techniques complexes tout en maintenant l'accent sur l'expérience utilisateur et les objectifs commerciaux. Mon expérience couvre l'ensemble du cycle de développement logiciel, de la conception initiale au déploiement et à la maintenance. J'ai travaillé en collaboration avec des équipes interfonctionnelles, notamment des designers, des chefs de produit et des parties prenantes, pour fournir des solutions qui dépassent les attentes.",
      para3: "Ce qui me motive est l'opportunité de créer un impact significatif grâce à la technologie. Je suis particulièrement attiré par les projets qui repoussent les limites du possible, nécessitent une pensée innovante et, en fin de compte, améliorent la vie des gens ou les entreprises. Je crois au pouvoir d'un code propre et maintenable et à l'importance de l'apprentissage continu dans notre industrie en évolution rapide.",
      para4: "Je suis particulièrement enthousiaste à l'idée de travailler avec votre organisation en raison de votre réputation d'excellence et d'innovation. Je suis convaincu que mes compétences techniques, combinées à mon engagement envers la croissance professionnelle et le travail d'équipe, feraient de moi un atout précieux pour votre équipe.",
      para5: "Je me réjouis de l'opportunité de discuter de la façon dont mon expérience et mon enthousiasme peuvent contribuer au succès continu de votre organisation. Je vous remercie de considérer ma candidature.",
      closing: "Cordialement,",
      signature: "Votre Nom",
    },
  };

  const text = content[language];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">{t('letter.title')}</h1>
        <p className="text-lg text-slate-600">{t('letter.subtitle')}</p>
      </div>

      {/* Letter Content */}
      <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
        <div className="space-y-6 text-slate-700">
          {/* Date */}
          <div className="text-right text-slate-600">
            {new Date().toLocaleDateString(language === 'en' ? 'en-US' : 'fr-FR', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </div>

          {/* Greeting */}
          <p className="font-medium">{text.greeting}</p>

          {/* Body Paragraphs */}
          <p className="leading-relaxed">{text.para1}</p>
          <p className="leading-relaxed">{text.para2}</p>
          <p className="leading-relaxed">{text.para3}</p>
          <p className="leading-relaxed">{text.para4}</p>
          <p className="leading-relaxed">{text.para5}</p>

          {/* Closing */}
          <div className="pt-4 space-y-3">
            <p>{text.closing}</p>
            <p className="font-medium text-slate-900 pt-8">{text.signature}</p>
          </div>
        </div>
      </div>

      {/* Additional Info */}
      <div className="bg-slate-50 rounded-lg p-6 border border-slate-200">
        <h2 className="text-xl font-semibold text-slate-900 mb-4">
          {language === 'en' ? 'Why I\'m a Great Fit' : 'Pourquoi je suis un excellent candidat'}
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h3 className="font-medium text-slate-900">
              {language === 'en' ? 'Technical Excellence' : 'Excellence Technique'}
            </h3>
            <p className="text-sm text-slate-600">
              {language === 'en'
                ? 'Proven expertise in modern web technologies and best practices'
                : 'Expertise éprouvée dans les technologies web modernes et les meilleures pratiques'}
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium text-slate-900">
              {language === 'en' ? 'Team Player' : 'Esprit d\'équipe'}
            </h3>
            <p className="text-sm text-slate-600">
              {language === 'en'
                ? 'Strong collaboration skills with diverse, cross-functional teams'
                : 'Fortes compétences en collaboration avec des équipes diverses et interfonctionnelles'}
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium text-slate-900">
              {language === 'en' ? 'Problem Solver' : 'Résolution de problèmes'}
            </h3>
            <p className="text-sm text-slate-600">
              {language === 'en'
                ? 'Creative approach to complex challenges with practical solutions'
                : 'Approche créative des défis complexes avec des solutions pratiques'}
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium text-slate-900">
              {language === 'en' ? 'Continuous Learner' : 'Apprentissage continu'}
            </h3>
            <p className="text-sm text-slate-600">
              {language === 'en'
                ? 'Committed to staying current with evolving technologies'
                : 'Engagement à rester à jour avec les technologies en évolution'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

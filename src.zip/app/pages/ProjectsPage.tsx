import { useLanguage } from '../context/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { ExternalLink, Play } from 'lucide-react';

const projects = [
  {
    id: 1,
    titleEn: 'E-Commerce Platform',
    titleFr: 'Plateforme E-Commerce',
    descriptionEn: 'A full-stack e-commerce solution with payment integration, inventory management, and real-time analytics. Built with React, Node.js, and PostgreSQL.',
    descriptionFr: 'Une solution e-commerce complète avec intégration de paiement, gestion des stocks et analyses en temps réel. Développée avec React, Node.js et PostgreSQL.',
    image: 'https://images.unsplash.com/photo-1582138825658-fb952c08b282?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BlciUyMHdvcmtzcGFjZSUyMGxhcHRvcHxlbnwxfHx8fDE3NzAxMzA4NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    technologies: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
  },
  {
    id: 2,
    titleEn: 'Mobile Task Manager',
    titleFr: 'Gestionnaire de Tâches Mobile',
    descriptionEn: 'Cross-platform mobile application for task and project management with offline sync capabilities. Features include team collaboration, file sharing, and deadline tracking.',
    descriptionFr: 'Application mobile multiplateforme pour la gestion de tâches et projets avec capacités de synchronisation hors ligne. Fonctionnalités incluant la collaboration d\'équipe, le partage de fichiers et le suivi des échéances.',
    image: 'https://images.unsplash.com/photo-1723705027411-9bfc3c99c2e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkZW1vbnN0cmF0aW9ufGVufDF8fHx8MTc3MDIxODI5Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    technologies: ['React Native', 'Firebase', 'Redux', 'TypeScript'],
  },
  {
    id: 3,
    titleEn: 'Data Analytics Dashboard',
    titleFr: 'Tableau de Bord Analytique',
    descriptionEn: 'Interactive dashboard for visualizing complex datasets with custom charts, filters, and export capabilities. Processes millions of data points in real-time.',
    descriptionFr: 'Tableau de bord interactif pour visualiser des ensembles de données complexes avec graphiques personnalisés, filtres et capacités d\'exportation. Traite des millions de points de données en temps réel.',
    image: 'https://images.unsplash.com/photo-1713857297379-6fc26e70f581?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcHBsaWNhdGlvbiUyMGludGVyZmFjZXxlbnwxfHx8fDE3NzAyMTgyOTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    technologies: ['Vue.js', 'D3.js', 'Python', 'MongoDB'],
  },
];

export function ProjectsPage() {
  const { language, t } = useLanguage();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">{t('projects.title')}</h1>
        <p className="text-lg text-slate-600">{t('projects.subtitle')}</p>
      </div>

      {/* Projects Grid */}
      <div className="space-y-12">
        {projects.map((project, index) => (
          <Card key={project.id} className="overflow-hidden">
            <div className={`grid md:grid-cols-2 gap-6 ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
              {/* Content */}
              <div className={`${index % 2 === 1 ? 'md:order-2' : ''}`}>
                <CardHeader>
                  <CardTitle className="text-2xl">
                    {language === 'en' ? project.titleEn : project.titleFr}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {language === 'en' ? project.descriptionEn : project.descriptionFr}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Technologies */}
                  <div>
                    <h3 className="font-medium text-slate-900 mb-2">Technologies</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <Button variant="outline" className="gap-2">
                      <ExternalLink className="w-4 h-4" />
                      {t('projects.viewProject')}
                    </Button>
                  </div>
                </CardContent>
              </div>

              {/* Media */}
              <div className={`space-y-4 ${index % 2 === 1 ? 'md:order-1' : ''}`}>
                <div className="p-6 space-y-4">
                  {/* Screenshot */}
                  <div className="rounded-lg overflow-hidden shadow-md">
                    <ImageWithFallback
                      src={project.image}
                      alt={language === 'en' ? project.titleEn : project.titleFr}
                      className="w-full h-48 object-cover"
                    />
                  </div>

                  {/* Video Demo */}
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Play className="w-4 h-4 text-slate-700" />
                      <h3 className="font-medium text-slate-900">{t('projects.demo')}</h3>
                    </div>
                    <div className="aspect-video bg-slate-100 rounded-lg overflow-hidden shadow-md">
                      {/* Replace with your actual video URL */}
                      <iframe
                        src={project.videoUrl}
                        className="w-full h-full"
                        title={`${language === 'en' ? project.titleEn : project.titleFr} Demo`}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                      {/* For local videos, use:
                      <video controls className="w-full h-full">
                        <source src="/path-to-your-video.mp4" type="video/mp4" />
                      </video>
                      */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Additional Projects Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-semibold text-slate-900 mb-4">Additional Projects</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <h3 className="font-medium text-slate-900 mb-2">Project {i}</h3>
              <p className="text-sm text-slate-600 mb-3">Brief description of the project and its key features.</p>
              <Button variant="ghost" size="sm" className="w-full gap-2">
                <ExternalLink className="w-3 h-3" />
                View
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

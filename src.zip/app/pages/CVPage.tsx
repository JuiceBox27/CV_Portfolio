import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Download, FileText } from 'lucide-react';

export function CVPage() {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">{t('cv.title')}</h1>
        <Button className="gap-2">
          <Download className="w-4 h-4" />
          {t('cv.download')}
        </Button>
      </div>

      {/* PDF Viewer */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="aspect-[8.5/11] bg-slate-100 flex items-center justify-center">
          {/* Placeholder for PDF - Replace with actual PDF embed */}
          <div className="text-center p-8 max-w-2xl">
            <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 mb-4">{t('cv.placeholder')}</p>
            <div className="bg-white border-2 border-dashed border-slate-300 rounded-lg p-8">
              <p className="text-sm text-slate-500 mb-2">To embed your CV:</p>
              <code className="text-xs bg-slate-100 px-2 py-1 rounded block">
                {`<iframe src="your-cv.pdf" className="w-full h-full" />`}
              </code>
            </div>
          </div>
          
          {/* 
          Uncomment and replace with your actual PDF URL:
          <iframe
            src="/path-to-your-cv.pdf"
            className="w-full h-full"
            title="CV"
          />
          */}
        </div>
      </div>

      {/* Additional Info */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-semibold text-slate-900 mb-4">Quick Summary</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-slate-900 mb-2">Experience</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• Position at Company (2020-2024)</li>
              <li>• Previous Role at Organization (2018-2020)</li>
              <li>• Earlier Position (2016-2018)</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-slate-900 mb-2">Education</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• Master's Degree - University (2016)</li>
              <li>• Bachelor's Degree - College (2014)</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-slate-900 mb-2">Skills</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• Technical Skill 1</li>
              <li>• Technical Skill 2</li>
              <li>• Technical Skill 3</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-slate-900 mb-2">Languages</h3>
            <ul className="space-y-2 text-slate-600">
              <li>• English - Fluent</li>
              <li>• French - Fluent</li>
              <li>• Other Language - Proficient</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

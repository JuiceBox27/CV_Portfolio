import { useLanguage } from '../context/LanguageContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { MapPin, Trophy, Heart, Camera } from 'lucide-react';

const travels = [
  {
    id: 1,
    locationEn: 'Swiss Alps',
    locationFr: 'Alpes suisses',
    descriptionEn: 'Hiking through stunning mountain landscapes and experiencing alpine culture',
    descriptionFr: 'Randonnée à travers de magnifiques paysages de montagne et découverte de la culture alpine',
    image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAxMTA4ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2023',
  },
  {
    id: 2,
    locationEn: 'Japan',
    locationFr: 'Japon',
    descriptionEn: 'Exploring ancient temples, modern cities, and rich cultural traditions',
    descriptionFr: 'Exploration de temples anciens, de villes modernes et de riches traditions culturelles',
    image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAxMTA4ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2022',
  },
  {
    id: 3,
    locationEn: 'Iceland',
    locationFr: 'Islande',
    descriptionEn: 'Witnessing natural wonders including waterfalls, glaciers, and northern lights',
    descriptionFr: 'Découverte de merveilles naturelles, notamment des cascades, des glaciers et des aurores boréales',
    image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAxMTA4ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2021',
  },
];

const accomplishments = [
  {
    id: 1,
    titleEn: 'Hackathon Winner',
    titleFr: 'Gagnant de Hackathon',
    descriptionEn: 'First place in national coding competition with innovative AI solution',
    descriptionFr: 'Première place dans une compétition nationale de codage avec une solution IA innovante',
    year: '2024',
  },
  {
    id: 2,
    titleEn: 'Published Research',
    titleFr: 'Recherche publiée',
    descriptionEn: 'Co-authored paper on machine learning applications in healthcare',
    descriptionFr: 'Co-auteur d\'un article sur les applications de l\'apprentissage automatique dans les soins de santé',
    year: '2023',
  },
  {
    id: 3,
    titleEn: 'Open Source Contributor',
    titleFr: 'Contributeur Open Source',
    descriptionEn: 'Active contributor to major open-source projects with 500+ stars',
    descriptionFr: 'Contributeur actif à des projets open-source majeurs avec plus de 500 étoiles',
    year: '2020-2024',
  },
  {
    id: 4,
    titleEn: 'Marathon Finisher',
    titleFr: 'Finisseur de Marathon',
    descriptionEn: 'Completed first marathon in under 4 hours',
    descriptionFr: 'Premier marathon terminé en moins de 4 heures',
    year: '2022',
  },
];

const interests = [
  {
    icon: Camera,
    titleEn: 'Photography',
    titleFr: 'Photographie',
    descriptionEn: 'Landscape and travel photography enthusiast',
    descriptionFr: 'Passionné de photographie de paysage et de voyage',
  },
  {
    icon: Heart,
    titleEn: 'Volunteer Work',
    titleFr: 'Bénévolat',
    descriptionEn: 'Teaching coding to underprivileged youth',
    descriptionFr: 'Enseignement du codage aux jeunes défavorisés',
  },
  {
    icon: MapPin,
    titleEn: 'Adventure Sports',
    titleFr: 'Sports d\'aventure',
    descriptionEn: 'Rock climbing, hiking, and mountain biking',
    descriptionFr: 'Escalade, randonnée et VTT',
  },
];

export function PersonalPage() {
  const { language, t } = useLanguage();

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">{t('personal.title')}</h1>
        <p className="text-lg text-slate-600">{t('personal.subtitle')}</p>
      </div>

      {/* Travels Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <MapPin className="w-7 h-7 text-slate-700" />
          <h2 className="text-3xl font-semibold text-slate-900">{t('personal.trips')}</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {travels.map((travel) => (
            <Card key={travel.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video overflow-hidden">
                <ImageWithFallback
                  src={travel.image}
                  alt={language === 'en' ? travel.locationEn : travel.locationFr}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-xl">
                    {language === 'en' ? travel.locationEn : travel.locationFr}
                  </CardTitle>
                  <span className="text-sm text-slate-500">{travel.year}</span>
                </div>
                <CardDescription>
                  {language === 'en' ? travel.descriptionEn : travel.descriptionFr}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      {/* Accomplishments Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <Trophy className="w-7 h-7 text-slate-700" />
          <h2 className="text-3xl font-semibold text-slate-900">{t('personal.accomplishments')}</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {accomplishments.map((item) => (
            <Card key={item.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg">
                    {language === 'en' ? item.titleEn : item.titleFr}
                  </CardTitle>
                  <span className="text-sm font-medium text-slate-600 bg-slate-100 px-2 py-1 rounded">
                    {item.year}
                  </span>
                </div>
                <CardDescription>
                  {language === 'en' ? item.descriptionEn : item.descriptionFr}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      {/* Interests Section */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <Heart className="w-7 h-7 text-slate-700" />
          <h2 className="text-3xl font-semibold text-slate-900">{t('personal.interests')}</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {interests.map((interest, index) => {
            const Icon = interest.icon;
            return (
              <Card key={index}>
                <CardContent className="pt-6 text-center">
                  <Icon className="w-12 h-12 text-slate-700 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    {language === 'en' ? interest.titleEn : interest.titleFr}
                  </h3>
                  <p className="text-sm text-slate-600">
                    {language === 'en' ? interest.descriptionEn : interest.descriptionFr}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Personal Quote */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-lg shadow-lg p-8 md:p-12 text-center">
        <blockquote className="text-white">
          <p className="text-xl md:text-2xl italic mb-4">
            {language === 'en'
              ? '"The best way to predict the future is to create it."'
              : '"La meilleure façon de prédire l\'avenir est de le créer."'}
          </p>
          <footer className="text-slate-300">
            {language === 'en' ? '— Peter Drucker' : '— Peter Drucker'}
          </footer>
        </blockquote>
      </div>

      {/* Blog-style Section */}
      <div className="bg-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-semibold text-slate-900 mb-6">
          {language === 'en' ? 'Recent Experiences' : 'Expériences récentes'}
        </h2>
        <div className="space-y-6">
          <article className="border-l-4 border-slate-300 pl-4">
            <div className="text-sm text-slate-500 mb-1">February 2026</div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              {language === 'en'
                ? 'Learning New Technologies'
                : 'Apprentissage de nouvelles technologies'}
            </h3>
            <p className="text-slate-700">
              {language === 'en'
                ? 'Currently diving deep into cloud architecture and serverless technologies. Excited about the possibilities these tools bring to modern application development.'
                : 'Actuellement en immersion dans l\'architecture cloud et les technologies serverless. Enthousiasmé par les possibilités que ces outils apportent au développement d\'applications modernes.'}
            </p>
          </article>

          <article className="border-l-4 border-slate-300 pl-4">
            <div className="text-sm text-slate-500 mb-1">January 2026</div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              {language === 'en' ? 'Community Involvement' : 'Engagement communautaire'}
            </h3>
            <p className="text-slate-700">
              {language === 'en'
                ? 'Organized a local tech meetup focusing on best practices in software development. Great discussions and networking with fellow developers.'
                : 'Organisation d\'une rencontre tech locale axée sur les meilleures pratiques en développement logiciel. Excellentes discussions et réseautage avec d\'autres développeurs.'}
            </p>
          </article>
        </div>
      </div>
    </div>
  );
}

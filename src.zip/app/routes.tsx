import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { CVPage } from './pages/CVPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { AboutPage } from './pages/AboutPage';
import { LetterPage } from './pages/LetterPage';
import { PersonalPage } from './pages/PersonalPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: CVPage },
      { path: 'projects', Component: ProjectsPage },
      { path: 'about', Component: AboutPage },
      { path: 'letter', Component: LetterPage },
      { path: 'personal', Component: PersonalPage },
    ],
  },
]);
